﻿using System;
using OOP2.InterFace;

namespace OOP2
{
    public abstract class Actor : iActorBehavior
    {
        protected string name;

        protected bool isTakeOrder;

        protected bool isMakeOrder;

        public Actor(string name)
        {
            this.name = name;
        }

        public abstract string GetName();
        public abstract void SetName(string name);
        public bool IsTakeOrder
        {
            get { return isTakeOrder; }
            set { isTakeOrder = value; }
        }

        public bool IsMakeOrder
        {
            get { return isMakeOrder; }
            set { isMakeOrder = value; }
        }

        public Actor GetActor()
        {
            return this;
        }
        public abstract void SetTakeOrder(bool val);
        public abstract void SetMakeOrder(bool val);
    }
}
