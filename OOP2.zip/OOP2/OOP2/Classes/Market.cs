﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOP2.InterFace;

namespace OOP2.Classes
{
    public class Market : iMarcketBehavior, iQueueBehavior
    {
        private List<iActorBehavior> queue;

        public Market() 
        {
            this.queue = new List<iActorBehavior>();
        }

        public void AcceptToMarket(iActorBehavior actor)
        {
            Console.WriteLine(actor.GetActor().GetName() + " Клиент пришел в магазин ");
            TakeInQueue(actor);
        }
        public void TakeInQueue(iActorBehavior actor)
        {
            this.queue.Add(actor);
            Console.Write(actor.GetActor().GetName() + " Клиент добавлен в очередь ");
        }
        public void ReleaseFromMarket(List<Actor> actors)
        {
            foreach(Actor actor in actors)
            {
                Console.WriteLine(actor.GetName() + " Клиент ушел из магазина ");
                this.queue.Remove(actor);
            }
        }

        public void Update()
        {
            TakeOrder();
            GiveOrder();
            ReleaseFromQueue();
        }
        public void GiveOrder()
        {
            foreach(iActorBehavior actor in queue)
            {
                if (actor.IsMakeOrder)
                {
                    actor.SetTakeOrder(true);
                    Console.WriteLine(actor.GetActor().GetName() + " Клиент получил свой заказ ");
                }
            }
        }
        public void ReleaseFromQueue()
        {
            List<Actor> releaseActors = new List<Actor>();
            foreach(iActorBehavior actor in queue)
            {
                if (actor.IsTakeOrder)
                {
                    releaseActors.Add(actor.GetActor());
                    Console.WriteLine(actor.GetActor().GetName() + " Клиент ушёл из очереди ");
                }
            }
            ReleaseFromMarket(releaseActors);
        }
        public void TakeOrder()
        {
            foreach (iActorBehavior actor in queue)
            {
                if (!actor.IsMakeOrder)
                {
                    actor.SetMakeOrder(true);
                    Console.WriteLine(actor.GetActor().GetName() + " Клиент сделал заказ ");

                }
            }
        }
    }
}
