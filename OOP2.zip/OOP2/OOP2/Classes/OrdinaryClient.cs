﻿using OOP2.InterFace;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.Classes
{
    public class OrdinaryClient : Actor, IReturnOrder
    {
        public OrdinaryClient(string name): base(name) 
        {
        }

        public override string GetName()
        {
            return base.name;
        }
        public override void SetName(string name)
        {
            base.name = name;
        }
        public override void SetTakeOrder(bool val)
        {
            base.IsTakeOrder = val;
        }
        public override void SetMakeOrder(bool val)
        {
            base.IsMakeOrder = val;
        }
        public void RequestReturn()
        {
            Console.WriteLine($"{GetName()} запрашивает возврат товара.");
        }

        public void ProcessReturn()
        {
            Console.WriteLine($"Обработка возврата товара для клиента {GetName()}");
        }
        public new Actor GetActor()
        {
            return base.GetActor();
        }

    }
}
