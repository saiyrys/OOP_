﻿using OOP2.InterFace;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.Classes
{
    public class PromotionClient : Actor, IReturnOrder
    {
        private static int ClientId = 1;
        private readonly int clientID;
        private string promotionName;
        private static int numberOfParticipants;

        public PromotionClient(string name, string promotionName) : base(name)
        {
            this.promotionName = promotionName;
            this.clientID = ClientId;
            numberOfParticipants++;
        }
        public override string GetName()
        {
            return base.name;
        }

        public override void SetName(string name)
        {
            base.name = name;
        }

        public override void SetTakeOrder(bool val)
        {
            base.IsTakeOrder = val;
        }

        public override void SetMakeOrder(bool val)
        {
            base.IsMakeOrder = val;
        }
        public void RequestReturn()
        {
            Console.WriteLine($"{GetName()} запрашивает возврат товара.");
        }

        public void ProcessReturn()
        {
            Console.WriteLine($"Обработка возврата товара для клиента {GetName()}");
        }
        public new  Actor GetActor()
        {
            return base.GetActor();
        }

        public int GetClientId()
        {
            return clientID;
        }

        public string GetPromotionName()
        {
            return promotionName;
        }

        public static int GetNumberOfParticipants()
        {
            return numberOfParticipants;
        }

    }
}
