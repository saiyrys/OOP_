﻿using OOP2.InterFace;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.Classes
{
    public class TaxInspector : iActorBehavior
    {
        private string name;
        private bool isTakeOrder;
        private bool isMakeOrder;

        bool iActorBehavior.IsTakeOrder => TakeOrder();

        bool iActorBehavior.IsMakeOrder => MakeOrder();

        public TaxInspector()
        {
            this.name = "Tax Audit";
        }

        public string GetName()
        {
            return name;
        }

        public bool TakeOrder()
        {
            return isTakeOrder;
        }

        public bool MakeOrder()
        {
            return isMakeOrder;
        }

        public void SetTakeOrder(bool val)
        {
            isTakeOrder = val;
        }

        public void SetMakeOrder(bool val)
        {
            isMakeOrder = val;
        }

        public Actor GetActor()
        {
            // Возвращаем новый экземпляр OrdinaryClient с именем Tax Audit
            return new OrdinaryClient(name);
        }
    }
}
