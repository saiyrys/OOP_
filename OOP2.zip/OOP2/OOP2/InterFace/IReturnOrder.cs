﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.InterFace
{
    public interface IReturnOrder
    {
       
        void RequestReturn();
        void ProcessReturn();
    }
}
