﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2.InterFace
{
    public interface iActorBehavior
    {
        bool IsTakeOrder { get; }
        bool IsMakeOrder { get; }
        void SetTakeOrder(bool value);
        void SetMakeOrder(bool value);
        Actor GetActor();
    }
}
