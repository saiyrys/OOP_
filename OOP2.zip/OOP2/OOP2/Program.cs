﻿using OOP2.InterFace;
using OOP2.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Market magnit = new Market();

            iActorBehavior client1 = new OrdinaryClient("boris");
            iActorBehavior client2 = new OrdinaryClient("masha");
            iActorBehavior client3 = new SpecialClient("prezident", 1);
            iActorBehavior client4 = new TaxInspector();
            iActorBehavior client5 = new PromotionClient("Alexander", "Special Promotion");

            magnit.AcceptToMarket(client1);
            magnit.AcceptToMarket(client2);
            magnit.AcceptToMarket(client3);
            magnit.AcceptToMarket(client4);
            magnit.AcceptToMarket(client5);

            magnit.Update();
        }
    }
}
